export const environment = {
  firebase: {
    projectId: 'slack-clone-2c68f',
    appId: '1:511601501502:web:7d3ceb4d336d7b81c2786f',
    storageBucket: 'slack-clone-2c68f.appspot.com',
    apiKey: 'AIzaSyC1koO6-Tm22mKLcI9trTMsbDoUVW30rfk',
    authDomain: 'slack-clone-2c68f.firebaseapp.com',
    messagingSenderId: '511601501502',
  },
  production: true
};
