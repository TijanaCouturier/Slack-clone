import { Component, OnInit } from '@angular/core';
import { AngularFirestore, QueryFn } from '@angular/fire/compat/firestore';
import { MatDialog } from '@angular/material/dialog';
import { Channel } from 'src/models/channel.class';
import { User } from 'src/models/user.class';

@Component({
  selector: 'app-channel',
  templateUrl: './channel.component.html',
  styleUrls: ['./channel.component.scss']
})
export class ChannelComponent implements OnInit {
 // user = new User();
  channelId: string;
  allUsers = [];
  channel: Channel = new Channel();
  channelName: string;
 
  constructor(public dialog: MatDialog, private firestore: AngularFirestore) { 

    
  }
  filterTitle(ref) : QueryFn{
    return ref.orderBy('channelName', 'asc');
 }


  ngOnInit(): void {
    this.firestore
    .collection('channels',  this.filterTitle.bind(this))
    .valueChanges({idField: 'channelId'})
    .subscribe((changes: any) => {
      console.log('Received changes from DB', changes);
      this.allUsers = changes;
    });
  }




  commentarRoom(){
 
  }

}
